// cartRoute.js
const express = require('express');
const router = express.Router();
const { verifyToken } = require('../auth'); 

const db = require('../models');
const CartService = require('../services/cartService');
const CartController = require('../controllers/cartController');

const cartService = new CartService(db.Cart, db.Product);
const cartController = new CartController(cartService);

// Adicionar um produto na cesta - requer autenticação
router.post('/add', verifyToken, async (req, res) => {
    cartController.addItemToCart(req, res);
});

// Remover um produto da cesta - requer autenticação
router.delete('/remove/:id', verifyToken, async (req, res) => {
    cartController.removeItemFromCart(req, res);
});

// Visualizar a cesta - requer autenticação
router.get('/', verifyToken, async (req, res) => {
    cartController.getCart(req, res);
});

module.exports = router;
