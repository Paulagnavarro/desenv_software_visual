var express = require('express');
var router = express.Router();

const db = require('../models');
const SupplierService = require('../services/supplierService');
const SupplierController = require('../controllers/supplierController');

const supplierService = new SupplierService(db.Supplier);
const supplierController = new SupplierController(supplierService);

// Criação de um novo fornecedor
router.post('/', async (req, res) => {
    supplierController.createSupplier(req, res);
});

// Listar todos os fornecedores
router.get('/', async (req, res) => {
    supplierController.getAllSuppliers(req, res);
});

// Atualizar um fornecedor
router.put('/:id', async (req, res) => {
    supplierController.updateSupplier(req, res);
});

// Deletar um fornecedor
router.delete('/:id', async (req, res) => {
    supplierController.deleteSupplier(req, res);
});

module.exports = router;
