class SupplierController {
    constructor(SupplierService) {
        this.supplierService = SupplierService;
    }

    // Criar novo fornecedor
    async createSupplier(req, res) {
        const { nome, endereco, telefone, email } = req.body;
        try {
            const newSupplier = await this.supplierService.createSupplier(nome, endereco, telefone, email);
            res.status(201).json(newSupplier);
        } catch (error) {
            res.status(500).json({ error: 'Erro ao criar o fornecedor.' });
        }
    }

    // Listar fornecedores
    async getAllSuppliers(req, res) {
        try {
            const suppliers = await this.supplierService.getAllSuppliers();
            res.status(200).json(suppliers);
        } catch (error) {
            res.status(500).json({ error: 'Erro ao listar os fornecedores.' });
        }
    }

    // Atualizar fornecedor
    async updateSupplier(req, res) {
        const { id } = req.params;
        const updates = req.body;
        try {
            const updatedSupplier = await this.supplierService.updateSupplier(id, updates);
            if (!updatedSupplier) {
                res.status(404).json({ error: 'Fornecedor não encontrado.' });
            } else {
                res.status(200).json(updatedSupplier);
            }
        } catch (error) {
            res.status(500).json({ error: 'Erro ao atualizar o fornecedor.' });
        }
    }

    // Deletar fornecedor
    async deleteSupplier(req, res) {
        const { id } = req.params;
        try {
            const deleted = await this.supplierService.deleteSupplier(id);
            if (!deleted) {
                res.status(404).json({ error: 'Fornecedor não encontrado.' });
            } else {
                res.status(200).json({ message: 'Fornecedor deletado com sucesso.' });
            }
        } catch (error) {
            res.status(500).json({ error: 'Erro ao deletar o fornecedor.' });
        }
    }
}

module.exports = SupplierController;
