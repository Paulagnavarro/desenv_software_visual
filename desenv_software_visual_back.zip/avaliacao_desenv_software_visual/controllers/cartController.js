class CartController {
    constructor(CartService) {
        this.cartService = CartService;
    }

    // Adicionar um produto na cesta
    async addItemToCart(req, res) {
        try {
            console.log("Usuário autenticado:", req.user); 
            const userId = req.user.id; 
            const { productId, quantidade } = req.body;
    
            console.log("Dados recebidos:", { userId, productId, quantidade });
    
            const updatedCart = await this.cartService.addItemToCart(userId, productId, quantidade);
            res.status(200).json(updatedCart);
        } catch (error) {
            console.error("Erro ao adicionar item ao carrinho:", error.message);
            res.status(500).json({ error: error.message });
        }
    }
    
    // Remover um produto da cesta
    async removeItemFromCart(req, res) {
        try {
            const userId = req.user.id; 
            const { id: productId } = req.params; 

            const result = await this.cartService.removeItemFromCart(userId, productId);
            res.status(200).json(result);  
        } catch (error) {
            console.error("Erro ao remover item do carrinho:", error.message);
            res.status(500).json({ error: error.message });
        }
    }

    // Visualizar itens da cesta
    async getCart(req, res) {
        try {
            const cart = await this.cartService.getCart();
            res.status(200).json(cart);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }
}

module.exports = CartController;