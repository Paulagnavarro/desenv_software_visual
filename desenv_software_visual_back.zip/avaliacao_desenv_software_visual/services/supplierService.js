class SupplierService {
    constructor(SupplierModel) {
        this.Supplier = SupplierModel;
    }

    // Criar novo fornecedor
    async createSupplier(nome, endereco, telefone, email) {
        try {
            const newSupplier = await this.Supplier.create({ nome, endereco, telefone, email });
            return newSupplier;
        } catch (error) {
            throw error;
        }
    }
    
    // Listar fornecedores
    async getAllSuppliers() {
        try {
            const suppliers = await this.Supplier.findAll();
            return suppliers;
        } catch (error) {
            throw error;
        }
    }

    // Atualizar fornecedor
    async updateSupplier(id, updates) {
        try {
            const [updated] = await this.Supplier.update(updates, { where: { id } });
            return updated ? await this.Supplier.findByPk(id) : null;
        } catch (error) {
            throw error;
        }
    }

    // Deletar fornecedor
    async deleteSupplier(id) {
        try {
            const deleted = await this.Supplier.destroy({ where: { id } });
            return deleted;
        } catch (error) {
            throw error;
        }
    }
}

module.exports = SupplierService;
