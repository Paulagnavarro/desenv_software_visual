class CartService {
    constructor(CartModel, ProductModel) {
        this.Cart = CartModel;
        this.Product = ProductModel;
    }

    // Adicionar um produto à cesta
    async addItemToCart(userId, productId, quantidade) {
        try {
            if (isNaN(productId) || isNaN(quantidade)) {
                throw new Error('O ID do produto e a quantidade devem ser números');
            }

            const product = await this.Product.findByPk(productId);
            if (!product) {
                throw new Error('Produto não encontrado');
            }

            let cartItem = await this.Cart.findOne({ where: { userId, productId } });

            if (cartItem) {
                cartItem.quantidade += quantidade;
                await cartItem.save();
            } else {
                cartItem = await this.Cart.create({
                    userId,
                    productId,
                    quantidade
                });
            }

            return cartItem; 

        } catch (error) {
            throw error;  
        }
    }

    // Remover um produto da cesta
    async removeItemFromCart(userId, productId) {
        try {
            const cartItem = await this.Cart.findOne({ where: { userId, productId } });
            if (!cartItem) {
                throw new Error('Produto não encontrado no carrinho');
            }
    
            await cartItem.destroy();
    
            return { message: 'Item removido com sucesso' };
        } catch (error) {
            throw error; 
        }
    }

    // Visualizar itens da cesta
    async getCart() {
        try {
            const cartItems = await this.Cart.findAll({
                attributes: ['id', 'userId', 'productId', 'quantidade', 'createdAt', 'updatedAt']
            });
    
            if (!cartItems || cartItems.length === 0) {
                return { message: "Nenhum item encontrado no carrinho." }; 
            }
    
            return cartItems;
        } catch (error) {
            throw error;
        }
    }  
}
module.exports = CartService;
