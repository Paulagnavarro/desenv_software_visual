const Sequelize = require('sequelize');

module.exports = (sequelize) => {
    const Cart = sequelize.define('Cart', {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        userId: {
            type: Sequelize.INTEGER,
            allowNull: false,
            references: {
                model: 'Users', 
                key: 'id'
            },
            onDelete: 'CASCADE' 
        },
        productId: {
            type: Sequelize.INTEGER,
            allowNull: false,
            references: {
                model: 'Products',
                key: 'id'
            },
            onDelete: 'CASCADE'
        },
        quantidade: {
            type: Sequelize.INTEGER,
            allowNull: false
        }
    });

    Cart.associate = function(models) {
        Cart.belongsTo(models.User, { foreignKey: 'userId' });
        Cart.belongsTo(models.Product, { foreignKey: 'productId' }); 
    };

    return Cart;
};
