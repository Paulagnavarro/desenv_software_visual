import React, { useState } from "react";
import api from "../services/api";
import { TextField, Button, Grid, Typography, Container, Alert } from "@mui/material";
import { useNavigate } from "react-router-dom";  

const Register = () => {
  const [newUser, setNewUser] = useState({
    email: "",
    data_nasc: "",
    password: ""
  });
  const [error, setError] = useState(""); 
  const [success, setSuccess] = useState(""); 
  const navigate = useNavigate();  

  // Função para criar um novo usuário
  const handleCreateUser = async (e) => {
    e.preventDefault();

    if (!newUser.email || !newUser.data_nasc || !newUser.password) {
      setError("Todos os campos são obrigatórios.");
      return;
    }

    try {
      console.log("Dados enviados para API:", newUser);  

      const response = await api.post("/users/novouser", newUser);  
      console.log("Resposta da API:", response); 

      if (response.status === 201) {
        setSuccess("Usuário criado com sucesso!");
        setError("");
        setNewUser({ email: "", data_nasc: "", password: "" });

        setTimeout(() => {
          navigate("/login");
        }, 2000);
      }
    } catch (error) {
      console.error("Erro ao criar usuário:", error);  

      if (error.response) {
        console.log("Resposta de erro completa:", error.response);
        if (error.response.data.error) {
          setError(error.response.data.error);
        } else {
          setError(`Erro: ${error.response.status} - ${error.response.statusText}`);
        }
      } else {
        setError("Erro ao criar usuário. Verifique os dados e tente novamente.");
      }

      setSuccess("");
    }
  };

  return (
    <Container maxWidth="sm" sx={{ mt: 4 }}>
      <Typography variant="h4" gutterBottom>
        Cadastro de Usuário
      </Typography>

      {/* Exibição de erro */}
      {error && <Alert severity="error">{error}</Alert>}

      {/* Exibição de sucesso */}
      {success && <Alert severity="success">{success}</Alert>}

      <form onSubmit={handleCreateUser} style={{ marginBottom: "20px" }}>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Email"
              variant="outlined"
              type="email"
              value={newUser.email}
              onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
              required
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Data de Nascimento"
              variant="outlined"
              type="date"
              value={newUser.data_nasc}
              onChange={(e) => setNewUser({ ...newUser, data_nasc: e.target.value })}
              InputLabelProps={{
                shrink: true,
              }}
              required
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Senha"
              variant="outlined"
              type="password"
              value={newUser.password}
              onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
              required
            />
          </Grid>
        </Grid>
        <Button variant="contained" color="primary" type="submit" sx={{ mt: 2 }}>
          Criar Conta
        </Button>
      </form>
    </Container>
  );
};

export default Register;
