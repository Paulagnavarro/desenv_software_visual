import React, { useEffect, useState } from "react";
import api from "../services/api";
import { TextField, Button, Grid, Typography, Container, Alert, Card, CardContent, CardActions } from "@mui/material";
import { useNavigate } from "react-router-dom"; 

const Supplier = () => {
  const [suppliers, setSuppliers] = useState([]);
  const [newSupplier, setNewSupplier] = useState({
    nome: "",
    endereco: "",
    telefone: "",
    email: ""
  });
  const [error, setError] = useState(""); 
  const navigate = useNavigate();  

  // Função para buscar fornecedores ao carregar a página
  useEffect(() => {
    const fetchSuppliers = async () => {
      try {
        const response = await api.get("/supplier");
        setSuppliers(response.data);
      } catch (error) {
        setError("Erro ao buscar fornecedores. Verifique a conexão com o servidor.");
        console.error("Erro ao buscar fornecedores:", error);
      }
    };
    fetchSuppliers();
  }, []);

  // Função para criar um novo fornecedor
  const handleCreateSupplier = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post("/supplier", newSupplier);
      setSuppliers([...suppliers, response.data]);
      setNewSupplier({ nome: "", endereco: "", telefone: "", email: "" }); 
    } catch (error) {
      setError("Erro ao criar fornecedor. Verifique os dados informados.");
      console.error("Erro ao criar fornecedor:", error);
    }
  };

  // Função para redirecionar para a página de edição do fornecedor
  const handleEditSupplier = (id) => {
    navigate(`/edit-supplier/${id}`); 
  };

  // Função para remover um fornecedor
  const handleDeleteSupplier = async (id) => {
    try {
      await api.delete(`/supplier/${id}`);
      setSuppliers(suppliers.filter(supplier => supplier.id !== id));
    } catch (error) {
      setError("Erro ao remover fornecedor.");
      console.error("Erro ao remover fornecedor:", error);
    }
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Typography variant="h4" gutterBottom>
        Lista de Fornecedores
      </Typography>

      {/* Exibição de erro */}
      {error && <Alert severity="error">{error}</Alert>}

      <form onSubmit={handleCreateSupplier} style={{ marginBottom: "20px" }}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Nome"
              variant="outlined"
              value={newSupplier.nome}
              onChange={(e) => setNewSupplier({ ...newSupplier, nome: e.target.value })}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Endereço"
              variant="outlined"
              value={newSupplier.endereco}
              onChange={(e) => setNewSupplier({ ...newSupplier, endereco: e.target.value })}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Telefone"
              variant="outlined"
              value={newSupplier.telefone}
              onChange={(e) => setNewSupplier({ ...newSupplier, telefone: e.target.value })}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="E-mail"
              variant="outlined"
              value={newSupplier.email}
              onChange={(e) => setNewSupplier({ ...newSupplier, email: e.target.value })}
            />
          </Grid>
        </Grid>
        <Button variant="contained" color="primary" type="submit" sx={{ mt: 2 }}>
          Adicionar Fornecedor
        </Button>
      </form>

      {/* Exibição da lista de fornecedores */}
      {suppliers.length > 0 ? (
        suppliers.map((supplier) => (
          <Card key={supplier.id} sx={{ marginBottom: "10px" }} onClick={() => handleEditSupplier(supplier.id)}>
            <CardContent>
              <Typography variant="h6">{supplier.nome}</Typography>
              <p><strong>Endereço:</strong> {supplier.endereco}</p>
              <p><strong>Telefone:</strong> {supplier.telefone}</p>
              <p><strong>E-mail:</strong> {supplier.email}</p>
            </CardContent>
            <CardActions>
              <Button size="small" color="primary" onClick={(e) => { e.stopPropagation(); handleEditSupplier(supplier.id); }}>
                Editar
              </Button>
              <Button size="small" color="secondary" onClick={(e) => { e.stopPropagation(); handleDeleteSupplier(supplier.id); }}>
                Remover
              </Button>
            </CardActions>
          </Card>
        ))
      ) : (
        <Typography variant="body1">Nenhum fornecedor disponível.</Typography>
      )}
    </Container>
  );
};

export default Supplier;
