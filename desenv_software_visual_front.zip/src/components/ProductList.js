import React, { useEffect, useState } from "react";
import api from "../services/api";
import { TextField, Button, Grid, Typography, Container, Alert, Card, CardContent, CardActions } from "@mui/material";
import { useNavigate } from "react-router-dom";  

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [newProduct, setNewProduct] = useState({
    nome: "",
    descricao: "",
    preco: "",
    estoque: ""
  });
  const [error, setError] = useState(""); 
  const navigate = useNavigate(); 

  // Função para buscar produtos ao carregar a página
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await api.get("/products");
        setProducts(response.data);
      } catch (error) {
        setError("Erro ao buscar produtos. Verifique a conexão com o servidor.");
        console.error("Erro ao buscar produtos:", error);
      }
    };
    fetchProducts();
  }, []);

  // Função para criar um novo produto
  const handleCreateProduct = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post("/products", newProduct);
      setProducts([...products, response.data]);
      setNewProduct({ nome: "", descricao: "", preco: "", estoque: "" }); 
    } catch (error) {
      setError("Erro ao criar produto. Verifique os dados informados.");
      console.error("Erro ao criar produto:", error);
    }
  };

  // Função para redirecionar para a página de edição do produto
  const handleEditProduct = (id) => {
    navigate(`/edit-product/${id}`); 
  };

  // Função para remover um produto
  const handleDeleteProduct = async (id) => {
    try {
      await api.delete(`/products/${id}`);
      setProducts(products.filter(product => product.id !== id));
    } catch (error) {
      setError("Erro ao remover produto.");
      console.error("Erro ao remover produto:", error);
    }
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Typography variant="h4" gutterBottom>
        Lista de Produtos
      </Typography>

      {/* Exibição de erro */}
      {error && <Alert severity="error">{error}</Alert>}

      <form onSubmit={handleCreateProduct} style={{ marginBottom: "20px" }}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Nome"
              variant="outlined"
              value={newProduct.nome}
              onChange={(e) => setNewProduct({ ...newProduct, nome: e.target.value })}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Descrição"
              variant="outlined"
              value={newProduct.descricao}
              onChange={(e) => setNewProduct({ ...newProduct, descricao: e.target.value })}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Preço"
              variant="outlined"
              type="number"
              value={newProduct.preco}
              onChange={(e) => setNewProduct({ ...newProduct, preco: e.target.value })}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Estoque"
              variant="outlined"
              type="number"
              value={newProduct.estoque}
              onChange={(e) => setNewProduct({ ...newProduct, estoque: e.target.value })}
            />
          </Grid>
        </Grid>
        <Button variant="contained" color="primary" type="submit" sx={{ mt: 2 }}>
          Adicionar Produto
        </Button>
      </form>

      {/* Exibição da lista de produtos */}
      {products.length > 0 ? (
        products.map((product) => (
          <Card key={product.id} sx={{ marginBottom: "10px" }} onClick={() => handleEditProduct(product.id)}>
            <CardContent>
              <Typography variant="h6">{product.nome}</Typography>
              <p><strong>Descrição:</strong> {product.descricao}</p>
              <p><strong>Preço:</strong> R$ {product.preco}</p>
              <p><strong>Estoque:</strong> {product.estoque}</p>
            </CardContent>
            <CardActions>
              <Button size="small" color="primary" onClick={(e) => { e.stopPropagation(); handleEditProduct(product.id); }}>
                Editar
              </Button>
              <Button size="small" color="secondary" onClick={(e) => { e.stopPropagation(); handleDeleteProduct(product.id); }}>
                Remover
              </Button>
            </CardActions>
          </Card>
        ))
      ) : (
        <Typography variant="body1">Nenhum produto disponível.</Typography>
      )}
    </Container>
  );
};

export default ProductList;
