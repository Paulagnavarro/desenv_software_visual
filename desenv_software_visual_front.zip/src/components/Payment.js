import React, { useState } from "react";
import api from "../services/api";  

const Payment = () => {
  const [userId, setUserId] = useState(""); 
  const [valorTotal, setValorTotal] = useState("");  
  const [metodoPagamento, setMetodoPagamento] = useState(""); 
  const [error, setError] = useState("");  
  const [successMessage, setSuccessMessage] = useState(""); 

  // Função para processar pagamento via Cartão de Crédito
  const handleCreditCardPayment = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post("/payment/credit-card", {
        userId,
        valorTotal,
        metodoPagamento: "credit-card",
      });
      console.log("Pagamento aprovado:", response.data);
      setSuccessMessage("Pagamento via Cartão de Crédito realizado com sucesso!");
      setError(""); 
    } catch (error) {
      console.error("Erro ao processar pagamento:", error);
      setError("Erro ao processar pagamento.");
      setSuccessMessage(""); 
    }
  };

  // Função para processar pagamento via PIX
  const handlePixPayment = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post("/payment/pix", {
        userId,
        valorTotal,
        metodoPagamento: "pix", 
      });

      console.log("Pagamento via PIX aprovado:", response.data);

      setSuccessMessage("Pagamento via PIX realizado com sucesso!");
      setError(""); 
    } catch (error) {
      console.error("Erro ao processar pagamento via PIX:", error);
      setError("Erro ao processar pagamento.");
      setSuccessMessage(""); 
    }
  };

  return (
    <div className="payment-container" style={{ margin: "20px" }}>
      <h1>Formas de Pagamento</h1>

      {successMessage && <div className="success" style={{ marginBottom: "10px", color: "green" }}>{successMessage}</div>}
      {error && <div className="error" style={{ marginBottom: "10px", color: "red" }}>{error}</div>}

      {/* Formulário de pagamento - Cartão de Crédito */}
      {metodoPagamento === "credit-card" && (
        <form onSubmit={handleCreditCardPayment} style={{ marginBottom: "20px" }}>
          <h2>Pagamento - Cartão de Crédito</h2>
          <div style={{ marginBottom: "10px" }}>
            <label htmlFor="userId">ID do Usuário</label>
            <input
              type="number"
              id="userId"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              required
              style={{ padding: "8px", width: "100%", boxSizing: "border-box" }}
            />
          </div>
          <div style={{ marginBottom: "10px" }}>
            <label htmlFor="valorTotal">Valor Total</label>
            <input
              type="number"
              id="valorTotal"
              value={valorTotal}
              onChange={(e) => setValorTotal(e.target.value)}
              required
              style={{ padding: "8px", width: "100%", boxSizing: "border-box" }}
            />
          </div>
          <button type="submit" style={{ padding: "10px 20px", cursor: "pointer" }}>Pagar com Cartão de Crédito</button>
        </form>
      )}

      {/* Formulário de pagamento - PIX */}
      {metodoPagamento === "pix" && (
        <form onSubmit={handlePixPayment} style={{ marginBottom: "20px" }}>
          <h2>Pagamento - PIX</h2>
          <div style={{ marginBottom: "10px" }}>
            <label htmlFor="userId">ID do Usuário</label>
            <input
              type="number"
              id="userId"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              required
              style={{ padding: "8px", width: "100%", boxSizing: "border-box" }}
            />
          </div>
          <div style={{ marginBottom: "10px" }}>
            <label htmlFor="valorTotal">Valor Total</label>
            <input
              type="number"
              id="valorTotal"
              value={valorTotal}
              onChange={(e) => setValorTotal(e.target.value)}
              required
              style={{ padding: "8px", width: "100%", boxSizing: "border-box" }}
            />
          </div>
          <button type="submit" style={{ padding: "10px 20px", cursor: "pointer" }}>Pagar com PIX</button>
        </form>
      )}

      {/* Seção para selecionar o método de pagamento */}
      {!metodoPagamento && (
        <div className="payment-methods" style={{ marginTop: "20px" }}>
          <button onClick={() => setMetodoPagamento("credit-card")} style={{ marginRight: "10px", padding: "10px 20px", cursor: "pointer" }}>
            Pagar com Cartão de Crédito
          </button>
          <button onClick={() => setMetodoPagamento("pix")} style={{ padding: "10px 20px", cursor: "pointer" }}>
            Pagar com PIX
          </button>
        </div>
      )}
    </div>
  );
};

export default Payment;
