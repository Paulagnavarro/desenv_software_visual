import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../services/api";
import { TextField, Button, Container, Typography } from "@mui/material";

const EditSupplier = () => {
  const { id } = useParams();  
  const navigate = useNavigate();  
  const [supplier, setSupplier] = useState({
    nome: "",
    endereco: "",
    telefone: "",
    email: ""
  });

  useEffect(() => {
    const fetchSupplier = async () => {
      try {
        const response = await api.get(`/supplier/${id}`);
        setSupplier(response.data);
      } catch (error) {
        console.error("Erro ao buscar o fornecedor:", error);
      }
    };
    fetchSupplier();
  }, [id]);

  const handleUpdateSupplier = async (e) => {
    e.preventDefault();
    try {
      const response = await api.put(`/supplier/${id}`, supplier);
      navigate("/supplier");  
    } catch (error) {
      console.error("Erro ao atualizar o fornecedor:", error);
    }
  };

  return (
    <Container maxWidth="sm">
      <Typography variant="h4" gutterBottom>
        Editar Fornecedor
      </Typography>
      <form onSubmit={handleUpdateSupplier}>
        <TextField
          fullWidth
          label="Nome"
          variant="outlined"
          value={supplier.nome}
          onChange={(e) => setSupplier({ ...supplier, nome: e.target.value })}
        />
        <TextField
          fullWidth
          label="Endereço"
          variant="outlined"
          value={supplier.endereco}
          onChange={(e) => setSupplier({ ...supplier, endereco: e.target.value })}
        />
        <TextField
          fullWidth
          label="Telefone"
          variant="outlined"
          value={supplier.telefone}
          onChange={(e) => setSupplier({ ...supplier, telefone: e.target.value })}
        />
        <TextField
          fullWidth
          label="E-mail"
          variant="outlined"
          value={supplier.email}
          onChange={(e) => setSupplier({ ...supplier, email: e.target.value })}
        />
        <Button variant="contained" color="primary" type="submit" sx={{ mt: 2 }}>
          Atualizar Fornecedor
        </Button>
      </form>
    </Container>
  );
};

export default EditSupplier;
