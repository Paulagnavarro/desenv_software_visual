import React, { useEffect, useState } from "react";
import api from "../services/api";
import "../styles/global.css";

const Cart = () => {
  const [cart, setCart] = useState([]);
  const [products, setProducts] = useState([]);
  const [quantidade, setQuantidade] = useState(1);

  // Carregar os produtos disponíveis
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await api.get("/products");
        setProducts(response.data);
      } catch (error) {
        console.error("Erro ao carregar produtos:", error);
      }
    };
    fetchProducts();
  }, []);

  // Carregar a cesta de compras
  useEffect(() => {
    const fetchCart = async () => {
      try {
        const response = await api.get("/cart", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        setCart(response.data);
      } catch (error) {
        console.error("Erro ao buscar a cesta:", error);
      }
    };

    fetchCart();
  }, []);

  // Função para adicionar um item à cesta
  const handleAddItemToCart = async (productId) => {
    try {
      console.log("Adicionando ao carrinho:", { productId, quantidade }); 
      const response = await api.post("/cart/add", { productId, quantidade });
      setCart([...cart, response.data]);
      alert("Produto adicionado com sucesso!");
    } catch (error) {
      if (error.response && error.response.status === 401) {
        alert("Erro de autenticação: faça login novamente.");
      } else {
        console.error("Erro ao adicionar produto:", error.response ? error.response.data : error.message);
        alert("Erro ao adicionar produto. Por favor, tente novamente.");
      }
    }
  };

  
  const handleRemoveItem = async (productId) => {
    try {
      await api.delete(`/cart/remove/${productId}`);
      setCart(cart.filter((item) => item.productId !== productId));
      alert("Produto removido com sucesso!");
    } catch (error) {
      console.error("Erro ao remover item:", error);
    }
  };
  
  // Função para obter o nome do produto pelo productId
  const getProductName = (productId) => {
    const product = products.find((p) => p.id === productId);
    return product ? product.nome : "Produto não encontrado";
  };

  return (
    <div className="container">
      <h1>Cesta de Compras</h1>
      {cart.length === 0 ? (
        <p>Cesta vazia</p>
      ) : (
        cart.map((item) => (
          <div key={item.productId} className="cart-item">
            <div>
              <h3>{getProductName(item.productId)}</h3> {/* Nome do produto */}
              <p>Quantidade: {item.quantidade}</p>
            </div>
            <button onClick={() => handleRemoveItem(item.productId)}>Remover</button>
          </div>
        ))
      )}

      <h2>Adicionar Produto</h2>
      {products.length === 0 ? (
        <p>Carregando produtos...</p>
      ) : (
        <div>
          <select onChange={(e) => setQuantidade(Number(e.target.value))} value={quantidade}>
            {[...Array(10)].map((_, i) => (
              <option key={i} value={i + 1}>
                {i + 1}
              </option>
            ))}
          </select>

          <div>
            {products.map((product) => (
              <div key={product.id}>
                <h3>{product.nome}</h3>
                <button onClick={() => handleAddItemToCart(product.id)}>
                  Adicionar à Cesta
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;
