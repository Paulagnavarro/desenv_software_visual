import React from "react";
import { BrowserRouter as Router, Route, Routes, Navigate } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./components/Login";
import Register from "./components/Register";
import ProductList from "./components/ProductList";
import Cart from "./components/Cart";
import Payment from "./components/Payment";
import Profile from "./pages/Profile";
import EditProduct from "./components/EditProduct";
import Supplier from "./components/Supplier";
import EditSupplier from "./components/EditSupplier";

function App() {
  const isAuthenticated = !!localStorage.getItem("token");

  return (
    <Router>
      <Routes>
        <Route path="/" element={isAuthenticated ? <Home /> : <Navigate to="/login" />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/products" element={isAuthenticated ? <ProductList /> : <Navigate to="/login" />} />
        <Route path="/supplier" element={isAuthenticated ? <Supplier /> : <Navigate to="/login" />} />
        <Route path="/cart" element={isAuthenticated ? <Cart /> : <Navigate to="/login" />} />
        <Route path="/payment" element={isAuthenticated ? <Payment /> : <Navigate to="/login" />} />
        <Route path="/profile" element={isAuthenticated ? <Profile /> : <Navigate to="/login" />} />
        <Route path="/edit-product/:id" element={isAuthenticated ? <EditProduct /> : <Navigate to="/login" />} />
        <Route path="/edit-supplier/:id" element={isAuthenticated ? <EditSupplier /> : <Navigate to="/login" />} />
      </Routes>
    </Router>
  );
}

export default App;
