import React from "react";
import { Link, useNavigate } from "react-router-dom";

const Home = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userId");
    navigate("/login");
  };

  return (
    <div className="container">
      <h1>Bem-vindo ao Sistema de E-commerce</h1>
      <nav>
        <ul>
          <li><Link to="/products">Produtos</Link></li>
          <li><Link to="/supplier">Fornecedores</Link></li>
          <li><Link to="/cart">Cesta</Link></li>
          <li><Link to="/payment">Pagamento</Link></li>
        </ul>
      </nav>
      <button onClick={handleLogout}>Logout</button>
    </div>
  );
};

export default Home;
